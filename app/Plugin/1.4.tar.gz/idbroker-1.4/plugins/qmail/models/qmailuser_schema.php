<?php
class QmailuserSchema extends QmailAppModel {
	var $name = 'QmailuserSchema';
}
?>
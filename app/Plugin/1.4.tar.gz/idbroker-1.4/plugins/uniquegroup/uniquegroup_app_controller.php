<?php
class UniquegroupAppController extends AppController {
	var $name = 'Uniquegroup';
}
?>

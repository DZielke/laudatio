<?php
class SudoSchema extends SudoAppModel {
	var $name = 'SudoSchema';
}
?>
<?php
class UniquegroupAppModel extends AppModel {
    var $name = 'Uniquegroup';
    var $useDbConfig = 'ldap';
    var $primaryKey = 'dn';
    var $useTable = '';
    
}
?>

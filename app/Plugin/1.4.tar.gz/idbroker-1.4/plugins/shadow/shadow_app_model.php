<?php
class ShadowAppModel extends AppModel {
    var $name = 'Shadow';
    var $useDbConfig = 'ldap';
    var $primaryKey = 'dn';
    var $useTable = '';
    
}
?>
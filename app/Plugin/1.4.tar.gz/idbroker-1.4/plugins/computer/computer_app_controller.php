<?php
class ComputerAppController extends AppController {
	var $name = 'Computer';
}
?>

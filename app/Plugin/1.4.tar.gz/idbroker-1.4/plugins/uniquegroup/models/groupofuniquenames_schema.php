<?php
class GroupofuniquenamesSchema extends UniquegroupAppModel {
	var $name = 'GroupofuniquenamesSchema';
}
?>

<?php
class ShadowaccountSchema extends ShadowAppModel {
	var $name = 'ShadowaccountSchema';
}
?>
<?php 
class DataManager extends AppModel {

	var $name = 'DataManager';
        var $useTable = array();
        var $uses = array();

}
?>

<?php
class PersonSchema extends PersonAppModel {
	var $name = 'PersonSchema';
}
?>

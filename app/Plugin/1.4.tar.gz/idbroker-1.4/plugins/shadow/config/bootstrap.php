<?php
	Configure::write('plugin.shadowaccount.label', 'Shadow Settings');
	Configure::write('plugin.shadowaccount.name', 'shadowaccount');
	Configure::write('plugin.shadowaccount.plugin', 'shadow');
?>
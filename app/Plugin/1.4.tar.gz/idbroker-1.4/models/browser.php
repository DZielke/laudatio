<?php 
class Browser extends AppModel {
    var $name = 'Browser';
    var $useDbConfig = 'ldap';
    var $primaryKey = 'dn';
    var $useTable = '';
}
?>

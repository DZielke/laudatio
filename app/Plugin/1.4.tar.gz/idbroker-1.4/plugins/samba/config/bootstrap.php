<?php
	Configure::write('plugin.sambasamaccount.label', 'Windows User');
	Configure::write('plugin.sambasamaccount.name', 'sambasamaccount');
	Configure::write('plugin.sambasamaccount.plugin', 'samba');
?>
<?php
class ShadowAppController extends AppController {
	var $name = 'Shadow';
}
?>
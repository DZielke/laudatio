<?php
class IphostSchema extends ComputerAppModel {
	var $name = 'IphostSchema';
}
?>

<?php
class PosixAppController extends AppController {
	var $name = 'Posix';
}
?>
<?php
class PersonAppController extends AppController {
	var $name = 'Person';
}
?>
